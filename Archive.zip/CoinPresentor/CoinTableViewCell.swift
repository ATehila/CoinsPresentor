//
//  CoinTableViewCell.swift
//  CoinPresentor
//
//  Created by David Salzer on 29/11/2019.
//  Copyright © 2019 David Salzer. All rights reserved.
//

import UIKit

class CoinTableViewCell: UITableViewCell {
    
    @IBOutlet weak var lblChange: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    
    @IBOutlet weak var viewPrice: UIView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func update(_ coin: Coin){
        lblName.text = coin.name
        lblPrice.text = String(coin.price)
        lblChange.text = String(coin.change)
        if coin.change == 0{
            viewPrice.backgroundColor = .white
        }else{
            viewPrice.backgroundColor = coin.change > 0 ? .green : .red
        }
    }
    
}
