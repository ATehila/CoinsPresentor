//
//  File.swift
//  CoinPresentor
//
//  Created by David Salzer on 28/11/2019.
//  Copyright © 2019 David Salzer. All rights reserved.
//

import Foundation

class Coin {
    let name : String
    var price : Float{
        didSet{
            change = (price - oldValue)/oldValue
        }
    }
    var change : Float
    
    init(name: String, price: Float) {
        self.name = name
        self.price = price
        change = 0.0
    }
}

