//
//  ViewController.swift
//  CoinPresentor
//
//  Created by David Salzer on 28/11/2019.
//  Copyright © 2019 David Salzer. All rights reserved.
//

import UIKit

enum SortType {
    case non
    case ascending
    case descending
}

class MainViewController: UIViewController, UITableViewDelegate,UITableViewDataSource{
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var lblChange: UILabel!
    var coins = [Coin]()
    var coinsDict = [String:Coin]()
    var sortType = SortType.non
    var timer : Timer?
    let interval = 2.0
    override func viewDidLoad() {
        
        super.viewDidLoad()
        lblChange.text = "Change (\(interval) min)"
        tableView.delegate = self
        tableView.dataSource = self
        startTimer()
        self.getJson()
        self.reloadData()
    }
    
    func startTimer(){
        timer = Timer.scheduledTimer(withTimeInterval: interval*60, repeats: true, block: { timer in
            self.getJson()
            self.reloadData()
        })
    }
    func getJson(){
        do {
            if let file = URL(string: "http://api.coinmarketcap.com/v2/ticker/?limit=20") {
                let data = try Data(contentsOf: file)
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                let coins = parsJsonToCoin(json: json)
                
            } else {
                print("no file")
            }
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func parsJsonToCoin(json:Any) -> [Coin]{
        coins = [Coin]()
        if  let object = json as? [String:Any] {
            for item in object {
                if item.key == "data"{
                    //  let coin = item.value
                    if  let jCoins = item.value as? [String:Any] {
                        
                        for coin in jCoins{
                            if  let coin = coin.value as? [String:Any] {
                                //       print(coin)
                                let name = coin["name"] as? String ?? ""
                                let quotes = coin["quotes"] as! [String:Any]
                                let usd = quotes["USD"] as! [String:Any]
                                let price = (usd["price"] as? NSNumber ?? 0).floatValue
                                if let coinDict = coinsDict[name]{
                                    coinDict.price = price
                                }
                                else{
                                    coinsDict[name] = Coin(name: name, price: price)
                                }
                                self.coins.append(coinsDict[name]!)
                            }
                        }
                    }
                }
                
            }
        }
        else {
            print("JSON is invalid")
        }
        return coins
    }
    
    @IBAction func priceDidPress(_ sender: UIButton) {
        switch sortType {
        case .non:
            sortType = .ascending
            break
        case .ascending:
            sortType = .descending
            break
        case .descending:
            sortType = .ascending
            break
        }
        reloadData()
    }
    
    //MARK: TableViewDataSource
    
    func reloadData(){
        
        switch sortType {
        case .non:
            break
        case .ascending:
            coins = coins.sorted(by: { $0.price > $1.price})
        case .descending:
            coins = coins.sorted(by: { $0.price < $1.price})
        }
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return coins.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let coin = coins[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "CoinCell" ,for: indexPath) as! CoinTableViewCell
        cell.update(coin)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
    
}




